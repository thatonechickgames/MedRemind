



import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
/**
 *
 * @author katiecole
 */
public class ICEPage extends javax.swing.JPanel {

    /**
     * Creates new form icePage
     */
    String contactName;
    String contactAddress;
    String contactPhoneNumber;
    String contactRelationshipType;
    
    String docName;
    String docAddress;
    String docPhoneNumber;
    String docSpecialty;
    String sqlString;
    
    int selection;
    int choice;
    
    Connection conn1 = null;
    Connection conn2 = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    DefaultListCellRenderer centerRender = new DefaultListCellRenderer();
    DefaultListModel ECL = new DefaultListModel();
    DefaultListModel DCL = new DefaultListModel();
    DefaultListModel ECIL = new DefaultListModel();
    DefaultListModel DCIL = new DefaultListModel();
    DefaultListModel CECL = new DefaultListModel();
    DefaultListModel CDCL = new DefaultListModel();
    
    public ICEPage() {
        initComponents();
        updateEmergContactList();
        updateDocContactList();
        initList1();
        initList2();
    }
    
    private void initList1()
    {

        conn1 = ICEPage.ConnectDB();
        stylizeList();
        emergContactList.setModel(ECL);
    
    }
    private void initList2()
    {

        conn2 = ICEPage.ConnectDB();
        stylizeList();
        docContactList.setModel(DCL);
        
    }
    
    private void stylizeList()
    {
                
        
        centerRender.setHorizontalAlignment(JLabel.CENTER);
        centerRender.setHorizontalTextPosition(JLabel.CENTER);
        centerRender.setVerticalAlignment(JLabel.CENTER);
        centerRender.setBorder(BorderFactory.createBevelBorder(1));
        
        
        emergContactList.setCellRenderer(centerRender);
        docContactList.setCellRenderer(centerRender);
        
    }
    
    public void getEmergContactInfo(){
        conn1 = ICEPage.ConnectDB();
        
        
        if (conn1 != null)
        {
            contactName = emergContactList.getSelectedValue();
            String sql = "Select * FROM Contacts WHERE Name = '" + contactName + "';";
            
            try
            {
                pst = conn1.prepareStatement(sql);
                rs = pst.executeQuery();

                while (rs.next()){
                                       
                    ECIL.addElement("Contact Name: " + rs.getString("Name"));
                    
                    String address = rs.getString("Address");
                    
                    if(!address.equals("null")){
                    ECIL.addElement("Address: " + rs.getString("Address"));
                    }
                    
                    ECIL.addElement("Phone Number: " + rs.getString("Phone"));
                    
                    ECIL.addElement("Relationship: " + rs.getString("Relationship"));
  
                }
                
                pst.close();
                rs.close();
                emergContactInfoList.setModel(ECIL);
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    public void getDocContactInfo(){
        conn2 = ICEPage.ConnectDB2();
        
        
        if (conn2 != null)
        {
            docName = docContactList.getSelectedValue();
            String sql = "Select * FROM Doctors WHERE Name = '" + docName + "';";
            
            try
            {
                pst = conn2.prepareStatement(sql);
                rs = pst.executeQuery();

                while (rs.next()){
                                       
                    DCIL.addElement("Doctor's Name: " + rs.getString("Name"));
                    
                    String address = rs.getString("Address");
                    
                    if(!address.equals("null")){
                    DCIL.addElement("Address: " + rs.getString("Address"));
                    }
                    
                    DCIL.addElement("Phone Number: " + rs.getString("Phone"));
                    
                    DCIL.addElement("Specialty: " + rs.getString("Specialty"));
  
                }
                
                pst.close();
                rs.close();
                docContactInfoList.setModel(DCIL);
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    
    public void editEmergContactInfo(){
        conn1 = ICEPage.ConnectDB();
        
        if (conn1 != null)
        {
            contactName = emergContactList.getSelectedValue();
            String sql = "Select * FROM Contacts WHERE Name = '" + contactName + "';";
            
            try
            {
                pst = conn1.prepareStatement(sql);
                rs = pst.executeQuery();

                while (rs.next()){
                                       
                    contactNameEdit.setText(rs.getString("Name"));
                    
                    String address = rs.getString("Address");
                    
                    if(address.equals("null") == true){
                    contactAddressEdit.setText("");
                    }
                    else{
                        contactAddressEdit.setText(rs.getString("Address"));
                    }
                     
                    contactPhoneEdit.setText(rs.getString("Phone")); 
                    contactRelationsEdit.setText(rs.getString("Relationship"));
                }
                
                pst.close();
                rs.close();
                emergContactInfoList.setModel(ECIL);
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    
    public void editDocContactInfo(){
        conn2 = ICEPage.ConnectDB2();
        
        if (conn2 != null)
        {
            docName = docContactList.getSelectedValue();
            String sql = "Select * FROM Doctors WHERE Name = '" + docName + "';";
            
            try
            {
                pst = conn2.prepareStatement(sql);
                rs = pst.executeQuery();

                while (rs.next()){
                                       
                    docNameEdit.setText(rs.getString("Name"));
                    
                    String address = rs.getString("Address");
                    
                    if(address.equals("null") == true){
                    docAddressEdit.setText("");
                    }
                    else{
                        docAddressEdit.setText(rs.getString("Address"));
                    }
                     
                    docPhoneEdit.setText(rs.getString("Phone"));
                    docSpecialtyEdit.setText(rs.getString("Specialty"));
                    
                }
                
                pst.close();
                rs.close();
                docContactList.setModel(DCIL);
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    
    //Functions to get Information to add a New Emergency contacts to ICE Doctor List
    public String getContactName()
    {   
        contactName = contactNameIn.getText();
        
        return contactName;
    }
    
    public String getNewAddress()
    {   
        contactAddress = contactAddressIn.getText();
        
        return contactAddress;
    }
    public String getNewPhoneNumber()
    {   
        contactPhoneNumber = contactPhoneIn.getText();
        
        return contactPhoneNumber;
    }
    public String getRelationshipType()
    {
        contactRelationshipType = contactRelationshipIn.getText();
        
        return contactRelationshipType;
    }
    
    //Functions to get Information to add a New Doctor to ICE Doctor List
    public String getDocName()
    {   
        docName = docNameIn.getText();
        
        return docName;
    }
    
    public String getDocAddress()
    {   
        docAddress = docAddressIn.getText();
        
        return docAddress;
    }
    public String getDocPhoneNumber()
    {   
        docPhoneNumber = docPhoneIn.getText();
        
        return docPhoneNumber;
    }
    public String getDocSpecialty()
    {
        docSpecialty = docSpecialtyIn.getText();
        
        return docSpecialty;
    }
    
    private void setConList(String contactName, String contactAddress, String contactPhoneNumber, String contactRelationshipType){

        CECL.clear();
        confirmContactsList.setModel(CECL);
        CECL.addElement(contactName);

        
        if(contactAddress != null){
                CECL.addElement("Address:  " + contactAddress);
            }else if(contactAddress == null){
                CECL.addElement("Address: Not Provided");
            }
        CECL.addElement("Phone Number: " + contactPhoneNumber);
        CECL.addElement("Relationship: " + contactRelationshipType);
    
      
    }
    private void setDocConList(String docName, String docAddress, String docPhoneNumber, String docSpecialty){

        CDCL.clear();
        confirmDocsList.setModel(CDCL);
        CDCL.addElement(docName);

        
        if(docAddress != null){
                CDCL.addElement("Address:  " + docAddress);
            }else if(docAddress == null){
                CDCL.addElement("Address: Not Provided");
            }
        CDCL.addElement("Phone Number: " + docPhoneNumber);
        CDCL.addElement("Specialty: " + docSpecialty);
    
      
    }
   
    public String createContactUpdateString(String contactName){
        
        String newContactName = contactNameEdit.getText();
        String newContactAdress = contactAddressEdit.getText();
        String newContactPhone = contactPhoneEdit.getText();
        String newContactRelationship = contactRelationsEdit.getText();
        
        
        
        sqlString = ("UPDATE Contacts SET "
            + "Name = '"
            + newContactName + "',"
            + "Address = '"
            + newContactAdress + "', "
            + "Phone = '"
            + newContactPhone + "', "
            + "Relationship = '"
            + newContactRelationship + "' "
            +  "WHERE Name = '" + contactName + "';");
        
        
        System.out.print(sqlString);
    
        return sqlString;
    }
    
    public String createDocUpdateString(String docName){
        
        String newDocName = docNameEdit.getText();
        String newDocAdress = docAddressEdit.getText();
        String newDocPhone = docPhoneEdit.getText();
        String newDocSpecialty = docSpecialtyEdit.getText();
        
        
        
        sqlString = ("UPDATE Doctors SET "
            + "Name = '"
            + newDocName + "',"
            + "Address = '"
            + newDocAdress + "', "
            + "Phone = '"
            + newDocPhone + "', "
            + "Specialty = '"
            + newDocSpecialty + "' "
            + "WHERE Name = '" + contactName + "';");
        
        
        System.out.print(sqlString);
    
        return sqlString;
    }
    
    public String createSQLString(String contactName, String contactAddress, String contactPhoneNumber, String contactRelationshipType){


        
        sqlString = ("INSERT INTO Contacts VALUES(" 
            + "'" + contactName + "',"
            + "'" + contactAddress + "', " 
            + "'" + contactPhoneNumber + "', "
            + "'" + contactRelationshipType + "'" +   ");");
        
        
        System.out.print(sqlString);
        return sqlString;
    }
    public String createDocSQLString(String docName, String docAddress, String docPhoneNumber, String docSpecialty){


        
        sqlString = ("INSERT INTO Doctors VALUES(" 
            + "'" + docName + "',"
            + "'" + docAddress + "', " 
            + "'" + docPhoneNumber + "', "
            + "'" + docSpecialty + "'" +   ");");
        
        
        System.out.print(sqlString);
        return sqlString;
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        topPanel = new javax.swing.JPanel();
        titleBar = new javax.swing.JLabel();
        myMedsButton = new javax.swing.JButton();
        upcomingRemindersButton = new javax.swing.JButton();
        iceButton = new javax.swing.JButton();
        profileOptionsButton = new javax.swing.JButton();
        bottomPanel = new javax.swing.JPanel();
        contactListPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        emergContactList = new javax.swing.JList<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        docContactList = new javax.swing.JList<>();
        addContactBttn = new javax.swing.JButton();
        addDoctorBttn = new javax.swing.JButton();
        emergContactInfoPanel = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        emergContactInfoList = new javax.swing.JList<>();
        EmerContactBackBttn = new javax.swing.JButton();
        EmergContactEditBttn = new javax.swing.JButton();
        docContactInfoPanel = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        docContactInfoList = new javax.swing.JList<>();
        DocContactBackBttn = new javax.swing.JButton();
        DocContactEditBttn = new javax.swing.JButton();
        editEmergContactPanel = new javax.swing.JPanel();
        EmerContactInfoBackBttn1 = new javax.swing.JButton();
        EmergContactConfirmBttn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        contactNameEdit = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        contactAddressEdit = new javax.swing.JTextField();
        contactPhoneEdit = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        contactRelationsEdit = new javax.swing.JTextField();
        contactInfoBackBttn = new javax.swing.JButton();
        contactInfoEditBttn = new javax.swing.JButton();
        editDocContactPanel = new javax.swing.JPanel();
        EmerContactInfoBackBttn2 = new javax.swing.JButton();
        EmergContactEditBttn2 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        docNameEdit = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        docAddressEdit = new javax.swing.JTextField();
        docPhoneEdit = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        docSpecialtyEdit = new javax.swing.JTextField();
        docInfoBackBttn = new javax.swing.JButton();
        docInfoEditConfirmBttn = new javax.swing.JButton();
        addNewContactPanel = new javax.swing.JPanel();
        contactNameIn = new javax.swing.JTextField();
        contactPhoneIn = new javax.swing.JTextField();
        contactAddressIn = new javax.swing.JTextField();
        contactRelationshipIn = new javax.swing.JTextField();
        contactNextButton = new javax.swing.JButton();
        addNewDocPanel = new javax.swing.JPanel();
        docNameIn = new javax.swing.JTextField();
        docPhoneIn = new javax.swing.JTextField();
        docAddressIn = new javax.swing.JTextField();
        docSpecialtyIn = new javax.swing.JTextField();
        confirmContactPanel = new javax.swing.JPanel();
        confirmContactNextButton = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        confirmContactsList = new javax.swing.JList<>();
        confirmDocPanel = new javax.swing.JPanel();
        confirmDocNextButton = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        confirmDocsList = new javax.swing.JList<>();

        setBackground(new java.awt.Color(255, 232, 214));
        setEnabled(false);
        setMaximumSize(new java.awt.Dimension(510, 800));
        setMinimumSize(new java.awt.Dimension(510, 800));
        setName("icePanel"); // NOI18N
        setPreferredSize(new java.awt.Dimension(510, 800));

        topPanel.setBackground(new java.awt.Color(255, 232, 214));
        topPanel.setPreferredSize(new java.awt.Dimension(510, 200));

        titleBar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleBar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Title Bar.png"))); // NOI18N
        titleBar.setAlignmentY(0.0F);
        titleBar.setIconTextGap(0);

        myMedsButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/My Meds Unclicked.png"))); // NOI18N
        myMedsButton.setBorderPainted(false);
        myMedsButton.setContentAreaFilled(false);

        upcomingRemindersButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Upcoming Reminders Unclicked.png"))); // NOI18N
        upcomingRemindersButton.setBorderPainted(false);
        upcomingRemindersButton.setContentAreaFilled(false);

        iceButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICE Clicked.png"))); // NOI18N
        iceButton.setBorderPainted(false);
        iceButton.setContentAreaFilled(false);

        profileOptionsButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Profile Options Unclicked.png"))); // NOI18N
        profileOptionsButton.setBorderPainted(false);
        profileOptionsButton.setContentAreaFilled(false);
        profileOptionsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                profileOptionsButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout topPanelLayout = new javax.swing.GroupLayout(topPanel);
        topPanel.setLayout(topPanelLayout);
        topPanelLayout.setHorizontalGroup(
            topPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(topPanelLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(myMedsButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(upcomingRemindersButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(iceButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(profileOptionsButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(48, 48, 48))
            .addGroup(topPanelLayout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(titleBar, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5))
        );
        topPanelLayout.setVerticalGroup(
            topPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(topPanelLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(titleBar, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(topPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(profileOptionsButton)
                    .addComponent(iceButton)
                    .addComponent(upcomingRemindersButton)
                    .addComponent(myMedsButton))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        bottomPanel.setBackground(new java.awt.Color(255, 232, 214));
        bottomPanel.setMaximumSize(new java.awt.Dimension(510, 600));
        bottomPanel.setMinimumSize(new java.awt.Dimension(510, 600));
        bottomPanel.setName(""); // NOI18N
        bottomPanel.setPreferredSize(new java.awt.Dimension(510, 600));
        bottomPanel.setLayout(new java.awt.CardLayout());

        contactListPanel.setBackground(new java.awt.Color(255, 232, 214));
        contactListPanel.setMaximumSize(new java.awt.Dimension(510, 800));
        contactListPanel.setPreferredSize(new java.awt.Dimension(510, 800));

        emergContactList.setBackground(new java.awt.Color(107, 112, 92));
        emergContactList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        emergContactList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                emergContactListMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(emergContactList);

        docContactList.setBackground(new java.awt.Color(107, 112, 92));
        docContactList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        docContactList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                docContactListMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(docContactList);

        addContactBttn.setText("Add New Contact");
        addContactBttn.setToolTipText("");
        addContactBttn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addContactBttnActionPerformed(evt);
            }
        });

        addDoctorBttn.setText("Add Doctor");
        addDoctorBttn.setActionCommand("Add New Doctor");

        javax.swing.GroupLayout contactListPanelLayout = new javax.swing.GroupLayout(contactListPanel);
        contactListPanel.setLayout(contactListPanelLayout);
        contactListPanelLayout.setHorizontalGroup(
            contactListPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contactListPanelLayout.createSequentialGroup()
                .addGroup(contactListPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(contactListPanelLayout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(contactListPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(contactListPanelLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addComponent(addDoctorBttn, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(contactListPanelLayout.createSequentialGroup()
                        .addGap(188, 188, 188)
                        .addComponent(addContactBttn)))
                .addContainerGap(60, Short.MAX_VALUE))
        );
        contactListPanelLayout.setVerticalGroup(
            contactListPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contactListPanelLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(addContactBttn)
                .addGap(24, 24, 24)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(addDoctorBttn)
                .addGap(0, 0, 0))
        );

        bottomPanel.add(contactListPanel, "card2");

        emergContactInfoPanel.setBackground(new java.awt.Color(255, 232, 214));

        jScrollPane3.setMaximumSize(new java.awt.Dimension(275, 300));
        jScrollPane3.setMinimumSize(new java.awt.Dimension(275, 300));
        jScrollPane3.setPreferredSize(new java.awt.Dimension(275, 300));

        emergContactInfoList.setBackground(new java.awt.Color(107, 112, 92));
        emergContactInfoList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        emergContactInfoList.setAutoscrolls(false);
        emergContactInfoList.setMaximumSize(new java.awt.Dimension(275, 300));
        emergContactInfoList.setMinimumSize(new java.awt.Dimension(275, 300));
        emergContactInfoList.setPreferredSize(new java.awt.Dimension(275, 300));
        jScrollPane3.setViewportView(emergContactInfoList);

        EmerContactBackBttn.setText("Back");
        EmerContactBackBttn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmerContactBackBttnActionPerformed(evt);
            }
        });

        EmergContactEditBttn.setText("Edit");
        EmergContactEditBttn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmergContactEditBttnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout emergContactInfoPanelLayout = new javax.swing.GroupLayout(emergContactInfoPanel);
        emergContactInfoPanel.setLayout(emergContactInfoPanelLayout);
        emergContactInfoPanelLayout.setHorizontalGroup(
            emergContactInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, emergContactInfoPanelLayout.createSequentialGroup()
                .addContainerGap(86, Short.MAX_VALUE)
                .addGroup(emergContactInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(emergContactInfoPanelLayout.createSequentialGroup()
                        .addComponent(EmerContactBackBttn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(EmergContactEditBttn))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(80, 80, 80))
        );
        emergContactInfoPanelLayout.setVerticalGroup(
            emergContactInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(emergContactInfoPanelLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 401, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addGroup(emergContactInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EmerContactBackBttn)
                    .addComponent(EmergContactEditBttn))
                .addContainerGap(126, Short.MAX_VALUE))
        );

        bottomPanel.add(emergContactInfoPanel, "card3");
        emergContactInfoPanel.setVisible(false);

        docContactInfoPanel.setBackground(new java.awt.Color(255, 232, 214));

        jScrollPane4.setBackground(new java.awt.Color(107, 112, 92));
        jScrollPane4.setForeground(new java.awt.Color(107, 112, 92));
        jScrollPane4.setPreferredSize(new java.awt.Dimension(275, 300));

        docContactInfoList.setBackground(new java.awt.Color(107, 112, 92));
        docContactInfoList.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        docContactInfoList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        docContactInfoList.setPreferredSize(new java.awt.Dimension(275, 300));
        jScrollPane4.setViewportView(docContactInfoList);

        DocContactBackBttn.setText("Back");
        DocContactBackBttn.setToolTipText("");
        DocContactBackBttn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DocContactBackBttnActionPerformed(evt);
            }
        });

        DocContactEditBttn.setText("Edit");
        DocContactEditBttn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DocContactEditBttnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout docContactInfoPanelLayout = new javax.swing.GroupLayout(docContactInfoPanel);
        docContactInfoPanel.setLayout(docContactInfoPanelLayout);
        docContactInfoPanelLayout.setHorizontalGroup(
            docContactInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(docContactInfoPanelLayout.createSequentialGroup()
                .addGroup(docContactInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(docContactInfoPanelLayout.createSequentialGroup()
                        .addGap(143, 143, 143)
                        .addComponent(DocContactBackBttn)
                        .addGap(73, 73, 73)
                        .addComponent(DocContactEditBttn))
                    .addGroup(docContactInfoPanelLayout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(94, Short.MAX_VALUE))
        );
        docContactInfoPanelLayout.setVerticalGroup(
            docContactInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(docContactInfoPanelLayout.createSequentialGroup()
                .addGap(266, 266, 266)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(docContactInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DocContactBackBttn)
                    .addComponent(DocContactEditBttn))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        bottomPanel.add(docContactInfoPanel, "card3");
        docContactInfoPanel.setVisible(false);

        editEmergContactPanel.setBackground(new java.awt.Color(255, 232, 214));

        EmerContactInfoBackBttn1.setText("Back");
        EmerContactInfoBackBttn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmerContactInfoBackBttn1ActionPerformed(evt);
            }
        });

        EmergContactConfirmBttn.setText("Edit");
        EmergContactConfirmBttn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmergContactConfirmBttnActionPerformed(evt);
            }
        });

        jLabel1.setText("Emergency Contact:");

        contactNameEdit.setText("jTextField1");

        jLabel2.setText("Address:");

        contactAddressEdit.setText("jTextField2");

        contactPhoneEdit.setText("jTextField3");

        jLabel3.setText("Phone Number:");

        jLabel4.setText("Specialty:");
        jLabel4.setToolTipText("");

        contactRelationsEdit.setText("jTextField4");

        contactInfoBackBttn.setText("Back");
        contactInfoBackBttn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contactInfoBackBttnActionPerformed(evt);
            }
        });

        contactInfoEditBttn.setText("Confirm");
        contactInfoEditBttn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contactInfoEditBttnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout editEmergContactPanelLayout = new javax.swing.GroupLayout(editEmergContactPanel);
        editEmergContactPanel.setLayout(editEmergContactPanelLayout);
        editEmergContactPanelLayout.setHorizontalGroup(
            editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editEmergContactPanelLayout.createSequentialGroup()
                .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(editEmergContactPanelLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addGap(27, 27, 27)
                        .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(contactAddressEdit, javax.swing.GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
                            .addComponent(contactPhoneEdit)
                            .addComponent(contactRelationsEdit)
                            .addComponent(contactNameEdit)))
                    .addGroup(editEmergContactPanelLayout.createSequentialGroup()
                        .addGap(103, 103, 103)
                        .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(editEmergContactPanelLayout.createSequentialGroup()
                                .addComponent(contactInfoBackBttn)
                                .addGap(86, 86, 86)
                                .addComponent(contactInfoEditBttn))
                            .addGroup(editEmergContactPanelLayout.createSequentialGroup()
                                .addComponent(EmerContactInfoBackBttn1)
                                .addGap(95, 95, 95)
                                .addComponent(EmergContactConfirmBttn)))))
                .addContainerGap(129, Short.MAX_VALUE))
        );
        editEmergContactPanelLayout.setVerticalGroup(
            editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editEmergContactPanelLayout.createSequentialGroup()
                .addGap(190, 190, 190)
                .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(editEmergContactPanelLayout.createSequentialGroup()
                        .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(contactNameEdit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(contactAddressEdit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(contactPhoneEdit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(contactRelationsEdit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(contactInfoBackBttn)
                    .addComponent(contactInfoEditBttn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 116, Short.MAX_VALUE)
                .addGroup(editEmergContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EmerContactInfoBackBttn1)
                    .addComponent(EmergContactConfirmBttn))
                .addGap(26, 26, 26))
        );

        bottomPanel.add(editEmergContactPanel, "card3");
        editEmergContactPanel.setVisible(false);

        editDocContactPanel.setBackground(new java.awt.Color(255, 232, 214));

        EmerContactInfoBackBttn2.setText("Back");
        EmerContactInfoBackBttn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmerContactInfoBackBttn2ActionPerformed(evt);
            }
        });

        EmergContactEditBttn2.setText("Edit");
        EmergContactEditBttn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmergContactEditBttn2ActionPerformed(evt);
            }
        });

        jLabel5.setText("Emergency Contact:");

        docNameEdit.setText("jTextField1");

        jLabel6.setText("Address:");

        docAddressEdit.setText("jTextField2");

        docPhoneEdit.setText("jTextField3");

        jLabel7.setText("Phone Number:");

        jLabel8.setText("Relationship:");
        jLabel8.setToolTipText("");

        docSpecialtyEdit.setText("jTextField4");

        docInfoBackBttn.setText("Back");
        docInfoBackBttn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                docInfoBackBttnActionPerformed(evt);
            }
        });

        docInfoEditConfirmBttn.setText("Confirm");

        javax.swing.GroupLayout editDocContactPanelLayout = new javax.swing.GroupLayout(editDocContactPanel);
        editDocContactPanel.setLayout(editDocContactPanelLayout);
        editDocContactPanelLayout.setHorizontalGroup(
            editDocContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editDocContactPanelLayout.createSequentialGroup()
                .addGroup(editDocContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(editDocContactPanelLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(editDocContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8))
                        .addGap(27, 27, 27)
                        .addGroup(editDocContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(docAddressEdit, javax.swing.GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
                            .addComponent(docPhoneEdit)
                            .addComponent(docSpecialtyEdit)
                            .addComponent(docNameEdit)))
                    .addGroup(editDocContactPanelLayout.createSequentialGroup()
                        .addGap(103, 103, 103)
                        .addGroup(editDocContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(EmerContactInfoBackBttn2)
                            .addComponent(docInfoBackBttn))
                        .addGap(73, 73, 73)
                        .addGroup(editDocContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(docInfoEditConfirmBttn)
                            .addComponent(EmergContactEditBttn2))))
                .addGap(111, 111, 111))
        );
        editDocContactPanelLayout.setVerticalGroup(
            editDocContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(editDocContactPanelLayout.createSequentialGroup()
                .addGap(190, 190, 190)
                .addGroup(editDocContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(editDocContactPanelLayout.createSequentialGroup()
                        .addGroup(editDocContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(docNameEdit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(editDocContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(docAddressEdit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(docPhoneEdit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addGroup(editDocContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(docSpecialtyEdit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(editDocContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(docInfoBackBttn)
                    .addComponent(docInfoEditConfirmBttn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 153, Short.MAX_VALUE)
                .addGroup(editDocContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EmerContactInfoBackBttn2)
                    .addComponent(EmergContactEditBttn2))
                .addGap(26, 26, 26))
        );

        bottomPanel.add(editDocContactPanel, "card3");
        editDocContactPanel.setVisible(false);

        addNewContactPanel.setBackground(new java.awt.Color(255, 232, 214));
        addNewContactPanel.setMaximumSize(new java.awt.Dimension(510, 600));
        addNewContactPanel.setPreferredSize(new java.awt.Dimension(510, 600));

        contactNameIn.setText("jTextField1");

        contactPhoneIn.setText("jTextField1");

        contactAddressIn.setText("jTextField2");

        contactRelationshipIn.setText("jTextField3");

        contactNextButton.setText("jButton1");
        contactNextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contactNextButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout addNewContactPanelLayout = new javax.swing.GroupLayout(addNewContactPanel);
        addNewContactPanel.setLayout(addNewContactPanelLayout);
        addNewContactPanelLayout.setHorizontalGroup(
            addNewContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addNewContactPanelLayout.createSequentialGroup()
                .addContainerGap(266, Short.MAX_VALUE)
                .addGroup(addNewContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(contactNextButton)
                    .addGroup(addNewContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(contactRelationshipIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(contactAddressIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(contactPhoneIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(contactNameIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(169, 169, 169))
        );
        addNewContactPanelLayout.setVerticalGroup(
            addNewContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addNewContactPanelLayout.createSequentialGroup()
                .addGap(205, 205, 205)
                .addComponent(contactNameIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(contactPhoneIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(contactAddressIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(contactRelationshipIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 144, Short.MAX_VALUE)
                .addComponent(contactNextButton)
                .addGap(92, 92, 92))
        );

        bottomPanel.add(addNewContactPanel, "card2");
        addNewContactPanel.setVisible(false);

        addNewDocPanel.setBackground(new java.awt.Color(255, 232, 214));
        addNewDocPanel.setMaximumSize(new java.awt.Dimension(510, 800));
        addNewDocPanel.setPreferredSize(new java.awt.Dimension(510, 800));

        docNameIn.setText("jTextField1");

        docPhoneIn.setText("jTextField1");

        docAddressIn.setText("jTextField2");

        docSpecialtyIn.setText("jTextField3");

        javax.swing.GroupLayout addNewDocPanelLayout = new javax.swing.GroupLayout(addNewDocPanel);
        addNewDocPanel.setLayout(addNewDocPanelLayout);
        addNewDocPanelLayout.setHorizontalGroup(
            addNewDocPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addNewDocPanelLayout.createSequentialGroup()
                .addContainerGap(266, Short.MAX_VALUE)
                .addGroup(addNewDocPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(docSpecialtyIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(docAddressIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(docPhoneIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(docNameIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(173, 173, 173))
        );
        addNewDocPanelLayout.setVerticalGroup(
            addNewDocPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addNewDocPanelLayout.createSequentialGroup()
                .addGap(205, 205, 205)
                .addComponent(docNameIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(docPhoneIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(docAddressIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(docSpecialtyIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(259, Short.MAX_VALUE))
        );

        bottomPanel.add(addNewDocPanel, "card2");
        addNewDocPanel.setVisible(false);

        confirmContactPanel.setBackground(new java.awt.Color(255, 232, 214));
        confirmContactPanel.setMaximumSize(new java.awt.Dimension(510, 600));
        confirmContactPanel.setPreferredSize(new java.awt.Dimension(510, 600));

        confirmContactNextButton.setText("jButton1");
        confirmContactNextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmContactNextButtonActionPerformed(evt);
            }
        });

        confirmContactsList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane5.setViewportView(confirmContactsList);

        javax.swing.GroupLayout confirmContactPanelLayout = new javax.swing.GroupLayout(confirmContactPanel);
        confirmContactPanel.setLayout(confirmContactPanelLayout);
        confirmContactPanelLayout.setHorizontalGroup(
            confirmContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, confirmContactPanelLayout.createSequentialGroup()
                .addContainerGap(266, Short.MAX_VALUE)
                .addComponent(confirmContactNextButton)
                .addGap(169, 169, 169))
            .addGroup(confirmContactPanelLayout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 404, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        confirmContactPanelLayout.setVerticalGroup(
            confirmContactPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(confirmContactPanelLayout.createSequentialGroup()
                .addGap(87, 87, 87)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
                .addComponent(confirmContactNextButton)
                .addGap(92, 92, 92))
        );

        bottomPanel.add(confirmContactPanel, "card2");
        confirmContactPanel.setVisible(false);

        confirmDocPanel.setBackground(new java.awt.Color(255, 232, 214));
        confirmDocPanel.setMaximumSize(new java.awt.Dimension(510, 600));
        confirmDocPanel.setPreferredSize(new java.awt.Dimension(510, 600));

        confirmDocNextButton.setText("jButton1");
        confirmDocNextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmDocNextButtonActionPerformed(evt);
            }
        });

        confirmDocsList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane6.setViewportView(confirmDocsList);

        javax.swing.GroupLayout confirmDocPanelLayout = new javax.swing.GroupLayout(confirmDocPanel);
        confirmDocPanel.setLayout(confirmDocPanelLayout);
        confirmDocPanelLayout.setHorizontalGroup(
            confirmDocPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, confirmDocPanelLayout.createSequentialGroup()
                .addContainerGap(266, Short.MAX_VALUE)
                .addComponent(confirmDocNextButton)
                .addGap(169, 169, 169))
            .addGroup(confirmDocPanelLayout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 404, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        confirmDocPanelLayout.setVerticalGroup(
            confirmDocPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(confirmDocPanelLayout.createSequentialGroup()
                .addGap(87, 87, 87)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
                .addComponent(confirmDocNextButton)
                .addGap(92, 92, 92))
        );

        bottomPanel.add(confirmDocPanel, "card2");
        confirmDocPanel.setVisible(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(topPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(bottomPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(topPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(bottomPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void profileOptionsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_profileOptionsButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_profileOptionsButtonActionPerformed

    private void emergContactListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_emergContactListMouseClicked
        if(evt.getClickCount() == 2 && evt.getButton() == MouseEvent.BUTTON1 && evt.getButton() != MouseEvent.BUTTON2){
            contactListPanel.setVisible(false);
            emergContactInfoPanel.setVisible(true);
            getEmergContactInfo();
        }
    }//GEN-LAST:event_emergContactListMouseClicked

    private void docContactListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_docContactListMouseClicked
        // TODO add your handling code here:
        if(evt.getClickCount() == 2 && evt.getButton() == MouseEvent.BUTTON1 && evt.getButton() != MouseEvent.BUTTON2){
            contactListPanel.setVisible(false);
            docContactInfoPanel.setVisible(true);
            getDocContactInfo();
        }
    }//GEN-LAST:event_docContactListMouseClicked

    private void addContactBttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addContactBttnActionPerformed
        // TODO add your handling code here:
        contactListPanel.setVisible(false);
        addNewContactPanel.setVisible(true);
        contactNameIn.requestFocus();
    }//GEN-LAST:event_addContactBttnActionPerformed

    private void EmerContactBackBttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmerContactBackBttnActionPerformed
        // TODO add your handling code here:
        emergContactInfoPanel.setVisible(false);
        ECIL.removeAllElements();
        contactListPanel.setVisible(true);
    }//GEN-LAST:event_EmerContactBackBttnActionPerformed

    private void EmergContactEditBttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmergContactEditBttnActionPerformed
        // TODO add your handling code here:
        emergContactInfoPanel.setVisible(false);

        editEmergContactPanel.setVisible(true);
        try{
            editEmergContactInfo();
        }catch(Exception e){

        }
    }//GEN-LAST:event_EmergContactEditBttnActionPerformed

    private void DocContactBackBttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DocContactBackBttnActionPerformed
        // TODO add your handling code here:
        docContactInfoPanel.setVisible(false);
        DCIL.removeAllElements();
        contactListPanel.setVisible(true);
    }//GEN-LAST:event_DocContactBackBttnActionPerformed

    private void DocContactEditBttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DocContactEditBttnActionPerformed
        // TODO add your handling code here:
        docContactInfoPanel.setVisible(false);

        editDocContactPanel.setVisible(true);
        try{
            editDocContactInfo();
        }catch(Exception e){

        }
    }//GEN-LAST:event_DocContactEditBttnActionPerformed

    private void EmerContactInfoBackBttn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmerContactInfoBackBttn1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EmerContactInfoBackBttn1ActionPerformed

    private void EmergContactConfirmBttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmergContactConfirmBttnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EmergContactConfirmBttnActionPerformed

    private void contactInfoBackBttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contactInfoBackBttnActionPerformed

        ECIL.removeAllElements();
        emergContactInfoList.setModel(ECIL);
        editEmergContactPanel.setVisible(false);
        contactListPanel.setVisible(true);
    }//GEN-LAST:event_contactInfoBackBttnActionPerformed

    private void contactInfoEditBttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contactInfoEditBttnActionPerformed
        // TODO add your handling code here:
        createContactUpdateString(contactName);
        updateDatabase1(sqlString);
        ECL.removeAllElements();
        emergContactList.setModel(ECL);
        ECIL.removeAllElements();
        emergContactInfoList.setModel(ECIL);
        updateEmergContactList();
        editEmergContactPanel.setVisible(false);
        contactListPanel.setVisible(true);
    }//GEN-LAST:event_contactInfoEditBttnActionPerformed

    private void EmerContactInfoBackBttn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmerContactInfoBackBttn2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EmerContactInfoBackBttn2ActionPerformed

    private void EmergContactEditBttn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmergContactEditBttn2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EmergContactEditBttn2ActionPerformed

    private void docInfoBackBttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_docInfoBackBttnActionPerformed

        DCIL.removeAllElements();
        docContactInfoList.setModel(DCIL);
        editDocContactPanel.setVisible(false);
        contactListPanel.setVisible(true);
    }//GEN-LAST:event_docInfoBackBttnActionPerformed

    private void contactNextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contactNextButtonActionPerformed
        setConList( contactName,  contactAddress,  contactPhoneNumber,  contactRelationshipType);
        addNewContactPanel.setVisible(false);
        confirmContactPanel.setVisible(true);
    }//GEN-LAST:event_contactNextButtonActionPerformed

    private void confirmContactNextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmContactNextButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_confirmContactNextButtonActionPerformed

    private void confirmDocNextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmDocNextButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_confirmDocNextButtonActionPerformed
    
    public static Connection ConnectDB()
    {
        try
        {
            Class.forName("org.sqlite.JDBC");
            Connection conn1 = DriverManager.getConnection("jdbc:sqlite:Contacts.db");
            return conn1;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
    
    public static Connection ConnectDB2()
    {
        try
        {
            Class.forName("org.sqlite.JDBC");
            Connection conn2 = DriverManager.getConnection("jdbc:sqlite:Doctors.db");
            return conn2;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
    
    public void updateDatabase1(String sqlString) throws NullPointerException
    {
        conn1 = ICEPage.ConnectDB();
        
        if (conn1 != null)
        {
            String sql = sqlString;
            
            try
            {
                int rows = 0;
                pst = conn1.prepareStatement(sql);
                rows = pst.executeUpdate();

                pst.close();
                rs.close();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        
    }
    
    public void updateDatabase2(String sqlString) throws NullPointerException
    {
        conn2 = ICEPage.ConnectDB2();
        
        if (conn2 != null)
        {
            String sql = sqlString;
            
            try
            {
                int rows = 0;
                pst = conn2.prepareStatement(sql);
                rows = pst.executeUpdate();

                pst.close();
                rs.close();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    
    public void cancelAction(){
            contactAddressIn.setText("");
            contactNameIn.setText("");
            contactPhoneIn.setText("");
            contactRelationshipIn.setText("");
            CECL.removeAllElements();
            confirmContactsList.setModel(CECL);
            ECIL.removeAllElements();
            emergContactInfoList.setModel(ECIL);
    }  
    
    public void updateEmergContactList()
    {
        conn1 = ICEPage.ConnectDB();
        
        if (conn1 != null)
        {
            String sql = "Select Name FROM Contacts;";
            
            try
            {
                pst = conn1.prepareStatement(sql);
                rs = pst.executeQuery();

                while (rs.next()){
                                       
                    ECL.addElement(rs.getString("Name"));
  
                }
                emergContactList.setModel(ECL);
                pst.close();
                rs.close();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    
    public void updateDocContactList()
    {
        conn2 = ICEPage.ConnectDB2();
        
        if (conn2 != null)
        {
            String sql = "Select * FROM Doctors;";
            
            try
            {
                pst = conn2.prepareStatement(sql);
                rs = pst.executeQuery();

                while (rs.next()){
                                       
                    DCL.addElement(rs.getString("Name"));
  
                }
                docContactList.setModel(DCL);
                pst.close();
                rs.close();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton DocContactBackBttn;
    private javax.swing.JButton DocContactEditBttn;
    private javax.swing.JButton EmerContactBackBttn;
    private javax.swing.JButton EmerContactInfoBackBttn1;
    private javax.swing.JButton EmerContactInfoBackBttn2;
    private javax.swing.JButton EmergContactConfirmBttn;
    private javax.swing.JButton EmergContactEditBttn;
    private javax.swing.JButton EmergContactEditBttn2;
    private javax.swing.JButton addContactBttn;
    private javax.swing.JButton addDoctorBttn;
    private javax.swing.JPanel addNewContactPanel;
    private javax.swing.JPanel addNewDocPanel;
    private javax.swing.JPanel bottomPanel;
    private javax.swing.JButton confirmContactNextButton;
    private javax.swing.JPanel confirmContactPanel;
    private javax.swing.JList<String> confirmContactsList;
    private javax.swing.JButton confirmDocNextButton;
    private javax.swing.JPanel confirmDocPanel;
    private javax.swing.JList<String> confirmDocsList;
    private javax.swing.JTextField contactAddressEdit;
    private javax.swing.JTextField contactAddressIn;
    private javax.swing.JButton contactInfoBackBttn;
    private javax.swing.JButton contactInfoEditBttn;
    private javax.swing.JPanel contactListPanel;
    private javax.swing.JTextField contactNameEdit;
    private javax.swing.JTextField contactNameIn;
    private javax.swing.JButton contactNextButton;
    private javax.swing.JTextField contactPhoneEdit;
    private javax.swing.JTextField contactPhoneIn;
    private javax.swing.JTextField contactRelationsEdit;
    private javax.swing.JTextField contactRelationshipIn;
    private javax.swing.JTextField docAddressEdit;
    private javax.swing.JTextField docAddressIn;
    private javax.swing.JList<String> docContactInfoList;
    private javax.swing.JPanel docContactInfoPanel;
    private javax.swing.JList<String> docContactList;
    private javax.swing.JButton docInfoBackBttn;
    private javax.swing.JButton docInfoEditConfirmBttn;
    private javax.swing.JTextField docNameEdit;
    private javax.swing.JTextField docNameIn;
    private javax.swing.JTextField docPhoneEdit;
    private javax.swing.JTextField docPhoneIn;
    private javax.swing.JTextField docSpecialtyEdit;
    private javax.swing.JTextField docSpecialtyIn;
    private javax.swing.JPanel editDocContactPanel;
    private javax.swing.JPanel editEmergContactPanel;
    private javax.swing.JList<String> emergContactInfoList;
    private javax.swing.JPanel emergContactInfoPanel;
    private javax.swing.JList<String> emergContactList;
    private javax.swing.JButton iceButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JButton myMedsButton;
    private javax.swing.JButton profileOptionsButton;
    private javax.swing.JLabel titleBar;
    private javax.swing.JPanel topPanel;
    private javax.swing.JButton upcomingRemindersButton;
    // End of variables declaration//GEN-END:variables
}
